function register() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  if (!username || !password) {
    alert("กรุณากรอกชื่อผู้ใช้และรหัสผ่าน");
    return;
  }

  if (localStorage.getItem(username)) {
    alert("มีผู้ใช้นี้อยู่แล้ว");
    return;
  }

  localStorage.setItem(username, password);
  alert("สมัครเรียบร้อยแล้ว");
}

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  const storedPassword = localStorage.getItem(username);
  if (storedPassword === password) {
    sessionStorage.setItem("loggedInUser", username);
    window.location.href = "topup.html";
  } else {
    alert("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
  }
}

function topup() {
  const user = sessionStorage.getItem("loggedInUser");
  if (!user) {
    alert("กรุณาเข้าสู่ระบบใหม่");
    window.location.href = "index.html";
    return;
  }

  const amount = document.getElementById("amount").value;
  document.getElementById("result").innerText = "เติมเงิน " + amount + " บาทสำเร็จ!";
}

window.onload = function () {
  const user = sessionStorage.getItem("loggedInUser");
  if (document.getElementById("currentUser")) {
    document.getElementById("currentUser").innerText = user || "ผู้ใช้";
  }
};
